# Railway deployment notes — ReBASE Radar

This project is ready for a single Railway service using the included Dockerfile and `railway.toml`.

## Required runtime settings

Set these environment variables in Railway:

- `RADAR_MCP_TOKEN`: long random secret
- `RADAR_ADMIN_TOKEN`: different long random secret
- `RADAR_DB=/data/radar.db`
- `RADAR_CONFIG=/app/config/targets.yaml`
- `RADAR_MAX_CONCURRENCY=8`
- `RADAR_USER_AGENT=ReBASE-Radar/0.3 (+owner-operated inventory monitor)`

Generate secrets locally with:

```bash
python scripts/generate_secrets.py
```

## Persistent data

Attach a Railway Volume mounted at:

```text
/data
```

The SQLite database is stored at `/data/radar.db`. Without a persistent volume, observations, subscriptions, dynamic targets and opportunities can disappear after redeploy/restart.

## Public networking

Generate a Railway domain for the service. The public health endpoint is:

```text
https://<your-domain>/health
```

The administrative read/write endpoints require the `X-Radar-Admin-Token` header. `/mcp` is protected with `Authorization: Bearer <RADAR_MCP_TOKEN>`.

## Smoke tests

```bash
curl https://<your-domain>/health

curl https://<your-domain>/targets \
  -H 'X-Radar-Admin-Token: YOUR_ADMIN_TOKEN'
```

Do not publish either secret in Git, screenshots, chat posts or source files.
