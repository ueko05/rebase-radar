# 30th CELEBRATION verified URL notes — 2026-10-07

## Amazon.co.jp — direct product pages

- Kanto: `B0GXCYMRGL`
- Johto: `B0GXCC7W7Q`
- Hoenn: `B0GXCX36HP`
- Sinnoh: `B0GXCX46KQ`
- Unova: `B0GXCZ1VDC`
- Kalos: `B0GXCSGX8Y`
- Alola: `B0GXCPF84C`
- Galar: `B0GXCTRZ8L`
- Paldea: `B0GXCT83HB`

All are configured as invitation/direct-offer monitors. `purchase.candidate` is suppressed unless the page changes to a direct-purchase state, price is <= ¥1,200, and seller `Amazon.co.jp` is verified.

## AEON STYLE online — confirmed direct pages

- Kanto JAN `4521329462295`
- Hoenn JAN `4521329462349`
- Sinnoh JAN `4521329462356`
- Kalos JAN `4521329462370`

Search results showed these pages at ¥1,199, but currently described them as lottery-winner-only purchase pages. The AEON adapter therefore suppresses purchase candidates while that wording is present and will fire when it changes to a normal cart state.

## Discovery / follow-up pages

- Pokémon official 30th product page
- Pokémon Center Online verified/unverified 9-set pages
- Yodobashi limited lottery page
- AmiAmi notices
- GEO 30th notice (explicitly says single-item sales may occur after lottery period)
- Lawson 10/16 sale notice
- Joshin 30th notice
- Furuichi 30th notice

These are page-change monitors, not auto-buy targets.

## Not yet added as direct-buy targets

Rakuten Books, BicCamera, Joshin Web, and some other major online retailers did not surface a stable 30th card-set direct-product URL in the 2026-10-07 search. They should remain Discovery targets until a direct product page is confirmed. Do not guess product URLs.
