from __future__ import annotations
from datetime import datetime, timezone
from uuid import uuid4
from .models import RadarEvent, Target, Observation


def derive_events(t: Target, prev: dict | None, cur: Observation) -> list[RadarEvent]:
    if cur.error: return []
    events=[]
    prev_stock = None if not prev else _to_bool(prev.get("in_stock"))
    prev_res = None if not prev else _to_bool(prev.get("reservation_open"))
    prev_raffle = None if not prev else _to_bool(prev.get("raffle_open"))
    prev_app = None if not prev else _to_bool(prev.get("application_open"))
    prev_mode = None if not prev else prev.get("offer_mode")

    if cur.in_stock is True and prev_stock is not True:
        events.append(_evt("inventory.available", t, cur))
    if cur.reservation_open is True and prev_res is not True:
        events.append(_evt("reservation.opened", t, cur))
    if cur.raffle_open is True and prev_raffle is not True:
        events.append(_evt("raffle.opened", t, cur))
    if cur.application_open is True and prev_app is not True:
        events.append(_evt("application.opened", t, cur))
    if cur.offer_mode and cur.offer_mode != prev_mode:
        events.append(_evt("offer.mode_changed", t, cur, extra={"offer_mode":cur.offer_mode,"previous_offer_mode":prev_mode}))

    mode = (t.metadata or {}).get("mode")
    if prev and mode in {"discovery", "announcement_monitor", "lottery_or_followup_monitor", "event_monitor"} and prev.get("fingerprint") != cur.fingerprint:
        events.append(_evt("page.changed", t, cur, extra={"mode":mode}))

    if _purchase_eligible(t, cur):
        price_changed = prev and prev.get("price_yen") != cur.price_yen
        seller_changed = prev and _to_bool(prev.get("seller_verified")) != cur.seller_verified
        if prev_stock is not True or price_changed or seller_changed:
            events.append(_evt("purchase.candidate", t, cur, extra={"decision":"candidate","max_price_yen":t.max_price_yen}))
    return events


def _purchase_eligible(t: Target, cur: Observation) -> bool:
    if cur.in_stock is not True or t.max_price_yen is None or cur.price_yen is None or cur.price_yen > t.max_price_yen:
        return False
    if (t.metadata or {}).get("purchase_eligible") is False: return False
    if (t.metadata or {}).get("seller_required") and cur.seller_verified is not True: return False
    if cur.offer_mode in {"invite_request", "lottery_winner_only", "unavailable"}: return False
    return True


def _evt(name: str, t: Target, cur: Observation, extra: dict | None = None) -> RadarEvent:
    data={
        "target_id":t.id,"product_name":t.name,"retailer":t.retailer,"url":t.url,
        "priority":t.priority,"price_yen":cur.price_yen,"expected_price_yen":t.expected_price_yen,
        "category":t.category,"seller_verified":cur.seller_verified,"offer_mode":cur.offer_mode,
        "metadata":t.metadata,
    }
    if extra: data.update(extra)
    return RadarEvent("evt_"+uuid4().hex,name,datetime.now(timezone.utc).isoformat(),data)


def _to_bool(v):
    if v is None: return None
    return bool(v)
