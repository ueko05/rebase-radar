from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any

@dataclass(slots=True)
class Target:
    id: str
    name: str
    url: str
    retailer: str
    category: str = "tcg"
    priority: str = "A"
    interval_seconds: int = 60
    expected_price_yen: int | None = None
    max_price_yen: int | None = None
    enabled: bool = True
    in_stock_any: list[str] = field(default_factory=list)
    out_of_stock_any: list[str] = field(default_factory=list)
    reservation_any: list[str] = field(default_factory=list)
    raffle_any: list[str] = field(default_factory=list)
    application_any: list[str] = field(default_factory=list)
    required_any: list[str] = field(default_factory=list)
    forbidden_any: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

@dataclass(slots=True)
class Observation:
    target_id: str
    checked_at: str
    http_status: int | None
    in_stock: bool | None
    reservation_open: bool | None
    raffle_open: bool | None
    price_yen: int | None
    fingerprint: str
    application_open: bool | None = None
    title: str | None = None
    error: str | None = None
    seller_verified: bool | None = None
    offer_mode: str | None = None

@dataclass(slots=True)
class RadarEvent:
    event_id: str
    name: str
    timestamp: str
    data: dict[str, Any]
