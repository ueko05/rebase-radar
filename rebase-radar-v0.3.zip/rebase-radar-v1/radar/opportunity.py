from __future__ import annotations
from datetime import datetime, timezone
from uuid import uuid4
from .models import RadarEvent

# Priority is operational urgency, not a promise of profit.
def priority_score(payload: dict) -> float:
    score=0.0
    kind=(payload.get("kind") or "").lower()
    if kind in {"stock","restock","first_come","reservation"}: score += 30
    elif kind in {"event_entry","raffle","lottery"}: score += 18
    elif kind in {"promo","freebie","collab"}: score += 15
    if payload.get("currently_available"): score += 25
    if payload.get("ends_at"): score += 8
    if payload.get("online"): score += 10
    if payload.get("user_eligible") is True: score += 12
    if payload.get("preferred_area") is True: score += 8
    if payload.get("card_related"): score += 7
    if payload.get("official_or_authorized", True): score += 5
    if payload.get("requires_unknown_eligibility"): score -= 10
    return max(0.0,min(100.0,score))


def opportunity_event(payload: dict) -> RadarEvent:
    data=dict(payload)
    data["priority_score"]=priority_score(payload)
    return RadarEvent("evt_"+uuid4().hex,"opportunity.discovered",datetime.now(timezone.utc).isoformat(),data)
