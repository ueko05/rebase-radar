from __future__ import annotations
import hashlib, json, re
from datetime import datetime, timezone
from bs4 import BeautifulSoup
import httpx
from .models import Observation, Target

_PRICE_PATTERNS = [
    re.compile(r"(?:￥|¥|税込|価格[:：]?\s*)\s*([0-9]{1,3}(?:,[0-9]{3})+|[0-9]{3,7})\s*円?"),
    re.compile(r"([0-9]{1,3}(?:,[0-9]{3})+)\s*円"),
]

async def probe_target(client: httpx.AsyncClient, t: Target) -> Observation:
    now = datetime.now(timezone.utc).isoformat()
    try:
        r = await client.get(t.url, follow_redirects=True, timeout=15)
        text = r.text
        normalized = " ".join(text.split())
        soup = BeautifulSoup(text, "html.parser")
        title = soup.title.get_text(" ", strip=True) if soup.title else None
        jsonld = _jsonld_availability(soup)
        adapter = (t.metadata or {}).get("adapter", "generic")
        parsed = _parse_by_adapter(adapter, normalized, t, jsonld, soup)
        price = parsed.get("price_yen") or _extract_price(normalized)
        fp = hashlib.sha256(_fingerprint_text(normalized).encode("utf-8", "ignore")).hexdigest()
        return Observation(
            t.id, now, r.status_code,
            parsed.get("in_stock"), parsed.get("reservation_open"), parsed.get("raffle_open"),
            price, fp, application_open=parsed.get("application_open"), title=title,
            seller_verified=parsed.get("seller_verified"),
            offer_mode=parsed.get("offer_mode"),
        )
    except Exception as e:
        return Observation(t.id, now, None, None, None, None, None, "error", error=f"{type(e).__name__}: {e}")


def _parse_by_adapter(adapter: str, text: str, t: Target, jsonld: bool | None, soup: BeautifulSoup) -> dict:
    if adapter == "amazon_jp":
        return _parse_amazon_jp(text, t, jsonld, soup)
    if adapter == "aeon_style":
        return _parse_aeon_style(text, t, jsonld)
    return {
        "in_stock": _detect_stock(text, t, jsonld),
        "reservation_open": _any(text, t.reservation_any),
        "raffle_open": _any(text, t.raffle_any),
        "application_open": _any(text, t.application_any),
        "seller_verified": None,
        "offer_mode": None,
    }


def _parse_amazon_jp(text: str, t: Target, jsonld: bool | None, soup: BeautifulSoup) -> dict:
    seller_required = (t.metadata or {}).get("seller_required")
    seller_verified = None
    if seller_required:
        patterns = [
            f"販売元 {seller_required}", f"販売元: {seller_required}", f"販売元：{seller_required}",
            f"Ships from {seller_required}", f"Sold by {seller_required}",
        ]
        seller_verified = _any(text, patterns)

    invite = _any(text, ["招待をリクエスト", "招待販売", "招待メール"])
    add_to_cart = _any(text, ["カートに入れる", "今すぐ買う", "Add to Cart", "Buy Now"])
    unavailable = _any(text, ["現在在庫切れ", "在庫切れ", "現在お取り扱いできません", "Currently unavailable"])

    if add_to_cart and not unavailable:
        in_stock = True; offer_mode = "direct_purchase"
    elif invite:
        in_stock = False; offer_mode = "invite_request"
    elif unavailable:
        in_stock = False; offer_mode = "unavailable"
    else:
        in_stock = jsonld; offer_mode = None

    return {
        "in_stock": in_stock,
        "reservation_open": invite or _any(text, t.reservation_any),
        "raffle_open": invite or _any(text, t.raffle_any),
        "application_open": _any(text, t.application_any),
        "seller_verified": seller_verified,
        "offer_mode": offer_mode,
        "price_yen": _amazon_price(soup),
    }


def _amazon_price(soup: BeautifulSoup) -> int | None:
    selectors = [
        "#corePrice_feature_div .a-price .a-offscreen",
        "#corePriceDisplay_desktop_feature_div .a-price .a-offscreen",
        "#price_inside_buybox",
        ".priceToPay .a-offscreen",
    ]
    for sel in selectors:
        node = soup.select_one(sel)
        if not node: continue
        m = re.search(r"([0-9]{1,3}(?:,[0-9]{3})+|[0-9]{3,7})", node.get_text(" ", strip=True))
        if m:
            try: return int(m.group(1).replace(",", ""))
            except ValueError: pass
    return None


def _parse_aeon_style(text: str, t: Target, jsonld: bool | None) -> dict:
    raffle_only = _any(text, ["抽選販売商品です。当選者の方のみ購入可能", "当選者の方のみ購入可能"])
    cart = _any(text, ["カートに入れる", "購入する", "注文する"])
    sold = _any(text, ["在庫切れ", "売り切れ", "販売終了", "予定数終了"])

    if raffle_only:
        in_stock = False; mode = "lottery_winner_only"
    elif cart and not sold:
        in_stock = True; mode = "direct_purchase"
    elif sold:
        in_stock = False; mode = "unavailable"
    else:
        in_stock = jsonld; mode = None

    return {
        "in_stock": in_stock,
        "reservation_open": _any(text, t.reservation_any),
        "raffle_open": raffle_only or _any(text, t.raffle_any),
        "application_open": _any(text, t.application_any),
        "seller_verified": True,
        "offer_mode": mode,
    }


def _any(text: str, needles: list[str]) -> bool:
    lower=text.lower()
    return any(n.lower() in lower for n in needles)


def _detect_stock(text: str, t: Target, jsonld: bool | None) -> bool | None:
    if t.forbidden_any and _any(text, t.forbidden_any): return False
    if t.required_any and not _any(text, t.required_any): return None
    if t.out_of_stock_any and _any(text, t.out_of_stock_any): return False
    if t.in_stock_any and _any(text, t.in_stock_any): return True
    return jsonld


def _extract_price(text: str) -> int | None:
    vals=[]
    for p in _PRICE_PATTERNS:
        for m in p.finditer(text):
            try: vals.append(int(m.group(1).replace(",", "")))
            except Exception: pass
    vals=[v for v in vals if 100 <= v <= 2_000_000]
    return min(vals) if vals else None


def _jsonld_availability(soup: BeautifulSoup) -> bool | None:
    found=[]
    for tag in soup.find_all("script", attrs={"type":"application/ld+json"}):
        try: obj=json.loads(tag.string or "{}")
        except Exception: continue
        stack=obj if isinstance(obj,list) else [obj]
        while stack:
            cur=stack.pop()
            if isinstance(cur,dict):
                av=cur.get("availability")
                if isinstance(av,str): found.append(av.lower())
                stack.extend(v for v in cur.values() if isinstance(v,(dict,list)))
            elif isinstance(cur,list): stack.extend(cur)
    if any("instock" in x or "limitedavailability" in x or "preorder" in x for x in found): return True
    if any("outofstock" in x or "soldout" in x for x in found): return False
    return None


def _fingerprint_text(text: str) -> str:
    return re.sub(r"\b\d{10,}\b", "#", text[:200_000])
