from __future__ import annotations
import asyncio, os
from uuid import uuid4
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from . import db
from .config import load_targets
from .engine import RadarEngine
from .mcp import discover, events_list, subscribe, unsubscribe, deliver_event
from .models import Target
from .opportunity import priority_score, opportunity_event

app=FastAPI(title="ReBASE Radar", version="0.3.0")
engine=RadarEngine()

class TargetIn(BaseModel):
    id: str
    name: str
    url: str
    retailer: str
    category: str="tcg"
    priority: str="A"
    interval_seconds: int=Field(default=60,ge=15)
    expected_price_yen: int | None=None
    max_price_yen: int | None=None
    enabled: bool=True
    in_stock_any: list[str]=Field(default_factory=list)
    out_of_stock_any: list[str]=Field(default_factory=list)
    reservation_any: list[str]=Field(default_factory=list)
    raffle_any: list[str]=Field(default_factory=list)
    application_any: list[str]=Field(default_factory=list)
    required_any: list[str]=Field(default_factory=list)
    forbidden_any: list[str]=Field(default_factory=list)
    metadata: dict=Field(default_factory=dict)

class OpportunityIn(BaseModel):
    id: str | None=None
    kind: str
    title: str
    ip: str | None=None
    source: str | None=None
    url: str | None=None
    starts_at: str | None=None
    ends_at: str | None=None
    location: str | None=None
    acquisition_cost_yen: int | None=None
    expected_price_yen: int | None=None
    estimated_supply: int | None=None
    status: str="new"
    currently_available: bool=False
    online: bool=False
    user_eligible: bool | None=None
    preferred_area: bool=False
    card_related: bool=False
    official_or_authorized: bool=True
    requires_unknown_eligibility: bool=False
    details: dict=Field(default_factory=dict)
    radar_target: TargetIn | None=None

@app.on_event("startup")
async def startup():
    db.init_db()
    engine.reload_targets()
    asyncio.create_task(engine.run())

@app.get("/health")
def health(): return {"ok":True,"targets":len(engine.targets),"version":"0.3.0"}

@app.get("/targets")
def targets(x_radar_admin_token: str | None = Header(default=None)):
    _admin_auth(x_radar_admin_token)
    return [t.to_dict() for t in load_targets()]

@app.get("/events")
def events(limit:int=100, x_radar_admin_token: str | None = Header(default=None)):
    _admin_auth(x_radar_admin_token)
    return db.recent_events(min(max(limit,1),500))

@app.get("/opportunities")
def opportunities(limit:int=100,status:str|None=None,x_radar_admin_token: str | None = Header(default=None)):
    _admin_auth(x_radar_admin_token)
    return db.list_opportunities(min(max(limit,1),500),status)

@app.post("/admin/targets")
def add_target(payload: TargetIn, x_radar_admin_token: str | None = Header(default=None)):
    _admin_auth(x_radar_admin_token)
    data=payload.model_dump()
    Target(**data)  # validate dataclass compatibility
    db.upsert_runtime_target(data,"dot")
    engine.reload_targets()
    return {"ok":True,"target_id":payload.id,"targets":len(engine.targets)}

@app.delete("/admin/targets/{target_id}")
def remove_target(target_id:str,x_radar_admin_token:str|None=Header(default=None)):
    _admin_auth(x_radar_admin_token)
    db.delete_runtime_target(target_id); engine.reload_targets()
    return {"ok":True,"target_id":target_id}

@app.post("/admin/opportunities")
async def ingest_opportunity(payload: OpportunityIn, x_radar_admin_token: str | None = Header(default=None)):
    _admin_auth(x_radar_admin_token)
    data=payload.model_dump(exclude={"radar_target"})
    data["id"]=data.get("id") or "opp_"+uuid4().hex
    data["priority_score"]=priority_score(data)
    if payload.radar_target:
        target_data=payload.radar_target.model_dump()
        db.upsert_runtime_target(target_data,"opportunity")
        data["radar_target_id"]=target_data["id"]
        engine.reload_targets()
    db.upsert_opportunity(data)
    event=opportunity_event(data)
    db.insert_event(event)
    await deliver_event(event)
    return {"ok":True,"opportunity_id":data["id"],"priority_score":data["priority_score"],"radar_target_id":data.get("radar_target_id")}

@app.post("/mcp")
async def mcp_endpoint(request: Request, authorization: str | None = Header(default=None)):
    token=os.getenv("RADAR_MCP_TOKEN")
    if token and token!="change-me" and authorization != f"Bearer {token}":
        raise HTTPException(status_code=401,detail="unauthorized")
    body=await request.json(); req_id=body.get("id"); method=body.get("method")
    if method=="server/discover": out=discover(req_id)
    elif method=="tools/list":
        from .mcp import tools_list
        out=tools_list(req_id)
    elif method=="tools/call":
        from .mcp import tools_call
        out=await tools_call(req_id,body.get("params") or {})
    elif method=="events/list": out=events_list(req_id)
    elif method=="events/subscribe": out=await subscribe(req_id,body.get("params") or {})
    elif method=="events/unsubscribe": out=await unsubscribe(req_id,body.get("params") or {})
    else: out={"jsonrpc":"2.0","id":req_id,"error":{"code":-32601,"message":"Method not found"}}
    return JSONResponse(out)


def _admin_auth(got: str | None):
    token=os.getenv("RADAR_ADMIN_TOKEN","change-me")
    if token != "change-me" and got != token:
        raise HTTPException(status_code=401,detail="unauthorized")
