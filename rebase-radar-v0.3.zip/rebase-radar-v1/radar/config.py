from __future__ import annotations
import os
from pathlib import Path
import yaml
from .models import Target


def _read_config(path: str | None = None) -> dict:
    p = Path(path or os.getenv("RADAR_CONFIG", "config/targets.yaml"))
    return yaml.safe_load(p.read_text(encoding="utf-8")) or {}


def _target_from_item(item: dict, defaults: dict | None = None) -> Target:
    merged={**(defaults or {}), **item}
    return Target(**merged)


def load_seed_targets(path: str | None = None) -> list[Target]:
    raw=_read_config(path); defaults=raw.get("defaults",{})
    return [t for t in (_target_from_item(i,defaults) for i in raw.get("targets",[])) if t.enabled]


def load_targets(path: str | None = None, include_runtime: bool = True) -> list[Target]:
    raw=_read_config(path); defaults=raw.get("defaults",{})
    seeds=[t for t in (_target_from_item(i,defaults) for i in raw.get("targets",[])) if t.enabled]
    by_id={t.id:t for t in seeds}
    if include_runtime:
        try:
            from . import db
            for item in db.list_runtime_targets():
                t=_target_from_item(item,defaults)
                if t.enabled: by_id[t.id]=t
        except Exception:
            pass
    return list(by_id.values())
