from __future__ import annotations
import json, os, sqlite3
from datetime import datetime, timezone
from typing import Any

DB_PATH = os.getenv("RADAR_DB", "radar.db")


def init_db() -> None:
    with sqlite3.connect(DB_PATH) as con:
        con.executescript("""
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS observations (
          target_id TEXT PRIMARY KEY,
          checked_at TEXT NOT NULL,
          http_status INTEGER,
          in_stock INTEGER,
          reservation_open INTEGER,
          raffle_open INTEGER,
          application_open INTEGER,
          price_yen INTEGER,
          fingerprint TEXT NOT NULL,
          title TEXT,
          error TEXT,
          seller_verified INTEGER,
          offer_mode TEXT
        );
        CREATE TABLE IF NOT EXISTS events (
          event_id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          timestamp TEXT NOT NULL,
          data_json TEXT NOT NULL,
          delivered INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS subscriptions (
          id TEXT PRIMARY KEY,
          event_name TEXT NOT NULL,
          arguments_json TEXT NOT NULL,
          callback_url TEXT NOT NULL,
          signing_secret TEXT NOT NULL,
          refresh_before TEXT,
          active INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS runtime_targets (
          id TEXT PRIMARY KEY,
          payload_json TEXT NOT NULL,
          source TEXT NOT NULL DEFAULT 'dot',
          enabled INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS opportunities (
          id TEXT PRIMARY KEY,
          discovered_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          kind TEXT NOT NULL,
          title TEXT NOT NULL,
          ip TEXT,
          source TEXT,
          url TEXT,
          starts_at TEXT,
          ends_at TEXT,
          location TEXT,
          acquisition_cost_yen INTEGER,
          expected_price_yen INTEGER,
          estimated_supply INTEGER,
          status TEXT NOT NULL DEFAULT 'new',
          radar_target_id TEXT,
          priority_score REAL,
          details_json TEXT NOT NULL
        );
        """)
        # Safe migrations for databases created by earlier v1 builds.
        cols={r[1] for r in con.execute("PRAGMA table_info(observations)").fetchall()}
        if "seller_verified" not in cols:
            con.execute("ALTER TABLE observations ADD COLUMN seller_verified INTEGER")
        if "offer_mode" not in cols:
            con.execute("ALTER TABLE observations ADD COLUMN offer_mode TEXT")
        if "application_open" not in cols:
            con.execute("ALTER TABLE observations ADD COLUMN application_open INTEGER")


def get_observation(target_id: str) -> dict[str, Any] | None:
    with sqlite3.connect(DB_PATH) as con:
        con.row_factory = sqlite3.Row
        row = con.execute("SELECT * FROM observations WHERE target_id=?", (target_id,)).fetchone()
        return dict(row) if row else None


def save_observation(obs: Any) -> None:
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""
        INSERT INTO observations(target_id, checked_at, http_status, in_stock, reservation_open,
          raffle_open, application_open, price_yen, fingerprint, title, error, seller_verified, offer_mode)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(target_id) DO UPDATE SET
          checked_at=excluded.checked_at,http_status=excluded.http_status,in_stock=excluded.in_stock,
          reservation_open=excluded.reservation_open,raffle_open=excluded.raffle_open,
          application_open=excluded.application_open,price_yen=excluded.price_yen,
          fingerprint=excluded.fingerprint,title=excluded.title,error=excluded.error,
          seller_verified=excluded.seller_verified,offer_mode=excluded.offer_mode
        """, (obs.target_id, obs.checked_at, obs.http_status, _b(obs.in_stock), _b(obs.reservation_open),
              _b(obs.raffle_open), _b(obs.application_open), obs.price_yen, obs.fingerprint, obs.title, obs.error,
              _b(obs.seller_verified), obs.offer_mode))


def insert_event(event: Any) -> None:
    with sqlite3.connect(DB_PATH) as con:
        con.execute("INSERT OR IGNORE INTO events(event_id,name,timestamp,data_json) VALUES(?,?,?,?)",
                    (event.event_id, event.name, event.timestamp, json.dumps(event.data, ensure_ascii=False)))


def recent_events(limit: int = 100) -> list[dict[str, Any]]:
    with sqlite3.connect(DB_PATH) as con:
        con.row_factory = sqlite3.Row
        rows = con.execute("SELECT * FROM events ORDER BY timestamp DESC LIMIT ?", (limit,)).fetchall()
        out=[]
        for r in rows:
            d=dict(r); d["data"]=json.loads(d.pop("data_json")); out.append(d)
        return out


def upsert_runtime_target(payload: dict[str, Any], source: str = "dot") -> None:
    now = datetime.now(timezone.utc).isoformat()
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""
        INSERT INTO runtime_targets(id,payload_json,source,enabled,created_at,updated_at)
        VALUES(?,?,?,?,?,?)
        ON CONFLICT(id) DO UPDATE SET payload_json=excluded.payload_json,source=excluded.source,
          enabled=excluded.enabled,updated_at=excluded.updated_at
        """, (payload["id"], json.dumps(payload,ensure_ascii=False), source, int(bool(payload.get("enabled",True))), now, now))


def delete_runtime_target(target_id: str) -> None:
    with sqlite3.connect(DB_PATH) as con:
        con.execute("UPDATE runtime_targets SET enabled=0,updated_at=? WHERE id=?",
                    (datetime.now(timezone.utc).isoformat(),target_id))


def list_runtime_targets() -> list[dict[str, Any]]:
    with sqlite3.connect(DB_PATH) as con:
        con.row_factory=sqlite3.Row
        rows=con.execute("SELECT payload_json FROM runtime_targets WHERE enabled=1 ORDER BY updated_at DESC").fetchall()
        return [json.loads(r["payload_json"]) for r in rows]


def upsert_opportunity(payload: dict[str, Any]) -> None:
    now=datetime.now(timezone.utc).isoformat()
    discovered=payload.get("discovered_at") or now
    details=payload.get("details") or {}
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""
        INSERT INTO opportunities(id,discovered_at,updated_at,kind,title,ip,source,url,starts_at,ends_at,location,
          acquisition_cost_yen,expected_price_yen,estimated_supply,status,radar_target_id,priority_score,details_json)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(id) DO UPDATE SET updated_at=excluded.updated_at,kind=excluded.kind,title=excluded.title,
          ip=excluded.ip,source=excluded.source,url=excluded.url,starts_at=excluded.starts_at,ends_at=excluded.ends_at,
          location=excluded.location,acquisition_cost_yen=excluded.acquisition_cost_yen,
          expected_price_yen=excluded.expected_price_yen,estimated_supply=excluded.estimated_supply,
          status=excluded.status,radar_target_id=excluded.radar_target_id,priority_score=excluded.priority_score,
          details_json=excluded.details_json
        """, (payload["id"],discovered,now,payload["kind"],payload["title"],payload.get("ip"),payload.get("source"),
              payload.get("url"),payload.get("starts_at"),payload.get("ends_at"),payload.get("location"),
              payload.get("acquisition_cost_yen"),payload.get("expected_price_yen"),payload.get("estimated_supply"),
              payload.get("status","new"),payload.get("radar_target_id"),payload.get("priority_score"),
              json.dumps(details,ensure_ascii=False)))


def list_opportunities(limit: int = 100, status: str | None = None) -> list[dict[str, Any]]:
    with sqlite3.connect(DB_PATH) as con:
        con.row_factory=sqlite3.Row
        q="SELECT * FROM opportunities"; args=[]
        if status:
            q += " WHERE status=?"; args.append(status)
        q += " ORDER BY priority_score DESC, discovered_at DESC LIMIT ?"; args.append(limit)
        rows=con.execute(q,args).fetchall()
        out=[]
        for r in rows:
            d=dict(r); d["details"]=json.loads(d.pop("details_json")); out.append(d)
        return out


def upsert_subscription(sub_id: str, event_name: str, arguments: dict, callback_url: str, secret: str, refresh_before: str | None) -> None:
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""
        INSERT INTO subscriptions(id,event_name,arguments_json,callback_url,signing_secret,refresh_before,active)
        VALUES(?,?,?,?,?,?,1)
        ON CONFLICT(id) DO UPDATE SET signing_secret=excluded.signing_secret,refresh_before=excluded.refresh_before,active=1
        """, (sub_id,event_name,json.dumps(arguments,sort_keys=True),callback_url,secret,refresh_before))


def delete_subscription(sub_id: str) -> None:
    with sqlite3.connect(DB_PATH) as con:
        con.execute("UPDATE subscriptions SET active=0 WHERE id=?", (sub_id,))


def list_subscriptions(event_name: str | None = None) -> list[dict[str, Any]]:
    with sqlite3.connect(DB_PATH) as con:
        con.row_factory=sqlite3.Row
        q="SELECT * FROM subscriptions WHERE active=1"; args=[]
        if event_name:
            q += " AND event_name=?"; args=[event_name]
        rows=con.execute(q,args).fetchall()
        out=[]
        for r in rows:
            d=dict(r); d["arguments"]=json.loads(d.pop("arguments_json")); out.append(d)
        return out


def _b(v):
    return None if v is None else int(bool(v))
