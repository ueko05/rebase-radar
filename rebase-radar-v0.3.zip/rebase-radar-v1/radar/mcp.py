from __future__ import annotations
import base64, hashlib, hmac, ipaddress, json, os, secrets, socket, time
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse
from uuid import uuid4
import httpx
from . import db
from .models import RadarEvent, Target
from .opportunity import priority_score, opportunity_event

PROTOCOL_VERSION="2026-07-28"
EVENTS = [
    ("inventory.available", "A monitored product changed to in-stock."),
    ("reservation.opened", "A monitored product opened first-come reservation/preorder."),
    ("raffle.opened", "A monitored product opened lottery/raffle applications."),
    ("application.opened", "An event or campaign opened participant applications."),
    ("purchase.candidate", "A known target is in stock and meets its configured price ceiling."),
    ("opportunity.discovered", "The discovery agent found a new product, event, promo or sales opportunity."),
]

TOOLS=[
    {
      "name":"radar_add_target",
      "description":"Add or update a direct product/event URL in the high-speed Radar. Use only after the source and URL are verified.",
      "inputSchema":{"type":"object","properties":{"target":{"type":"object"}},"required":["target"],"additionalProperties":False},
    },
    {
      "name":"radar_ingest_opportunity",
      "description":"Store a newly discovered product, promo, event, raffle or sales opportunity. Optionally attach a direct Radar target.",
      "inputSchema":{"type":"object","properties":{"opportunity":{"type":"object"},"radar_target":{"type":["object","null"]}},"required":["opportunity"],"additionalProperties":False},
    },
    {
      "name":"radar_list_targets",
      "description":"List currently enabled seed and dynamically added Radar targets.",
      "inputSchema":{"type":"object","properties":{},"additionalProperties":False},
    },
]


def discover(req_id):
    return {"jsonrpc":"2.0","id":req_id,"result":{"resultType":"complete","supportedVersions":[PROTOCOL_VERSION],"capabilities":{"tools":{},"events":{}}}}


def tools_list(req_id):
    return {"jsonrpc":"2.0","id":req_id,"result":{"tools":TOOLS}}


async def tools_call(req_id, params):
    name=params.get("name"); args=params.get("arguments") or {}
    try:
        if name=="radar_add_target":
            target=args.get("target") or {}
            Target(**target)
            db.upsert_runtime_target(target,"dot")
            result={"ok":True,"target_id":target["id"]}
        elif name=="radar_ingest_opportunity":
            opp=dict(args.get("opportunity") or {})
            if not opp.get("kind") or not opp.get("title"):
                return _err(req_id,-32602,"opportunity.kind and opportunity.title are required")
            opp["id"]=opp.get("id") or "opp_"+uuid4().hex
            rt=args.get("radar_target")
            if rt:
                Target(**rt); db.upsert_runtime_target(rt,"opportunity"); opp["radar_target_id"]=rt["id"]
            opp["priority_score"]=priority_score(opp)
            db.upsert_opportunity(opp)
            event=opportunity_event(opp); db.insert_event(event); await deliver_event(event)
            result={"ok":True,"opportunity_id":opp["id"],"priority_score":opp["priority_score"],"radar_target_id":opp.get("radar_target_id")}
        elif name=="radar_list_targets":
            from .config import load_targets
            result={"targets":[t.to_dict() for t in load_targets()]}
        else:
            return _err(req_id,-32602,"Unknown tool")
        return {"jsonrpc":"2.0","id":req_id,"result":{"content":[{"type":"text","text":json.dumps(result,ensure_ascii=False)}],"structuredContent":result}}
    except Exception as e:
        return _err(req_id,-32602,f"Invalid arguments: {e}")


def events_list(req_id):
    base_props={
        "target_id":{"type":"string"},"product_name":{"type":"string"},"retailer":{"type":"string"},
        "url":{"type":"string"},"priority":{"type":"string"},"price_yen":{"type":["integer","null"]},
        "expected_price_yen":{"type":["integer","null"]},"category":{"type":"string"},"metadata":{"type":"object"}
    }
    out=[]
    for name,desc in EVENTS:
        if name=="opportunity.discovered":
            payload={"type":"object","properties":{"id":{"type":"string"},"kind":{"type":"string"},"title":{"type":"string"},"source":{"type":["string","null"]},"url":{"type":["string","null"]},"priority_score":{"type":"number"}},"required":["id","kind","title"],"additionalProperties":True}
        else:
            p=dict(base_props)
            if name=="purchase.candidate": p.update({"decision":{"type":"string"},"max_price_yen":{"type":"integer"}})
            payload={"type":"object","properties":p,"required":["target_id","product_name","retailer","url","priority","category","metadata"],"additionalProperties":True}
        out.append({
            "name":name,"description":desc,"delivery":["webhook"],
            "inputSchema":{"type":"object","properties":{"target_id":{"type":"string"},"retailer":{"type":"string"},"priority":{"type":"string"}},"additionalProperties":False},
            "payloadSchema":payload,
        })
    return {"jsonrpc":"2.0","id":req_id,"result":{"events":out}}


async def subscribe(req_id, params):
    name=params.get("name"); args=params.get("arguments") or {}; delivery=params.get("delivery") or {}
    if name not in {e[0] for e in EVENTS}: return _err(req_id,-32602,"Unknown event")
    if delivery.get("mode")!="webhook": return _err(req_id,-32602,"Only webhook delivery is supported")
    url=delivery.get("url",""); secret=delivery.get("secret","")
    try: _validate_secret(secret); _validate_callback_url(url)
    except ValueError as e: return _err(req_id,-32602,str(e))
    ident=json.dumps(["single-user",url,name,args],sort_keys=True,separators=(",",":"))
    sub_id="sub_"+hashlib.sha256(ident.encode()).hexdigest()[:24]
    refresh=(datetime.now(timezone.utc)+timedelta(hours=24)).isoformat()
    ok=await verify_callback(sub_id,url,secret)
    if not ok: return _err(req_id,-32015,"CallbackEndpointError",{"reason":"challenge_failed"})
    db.upsert_subscription(sub_id,name,args,url,secret,refresh)
    return {"jsonrpc":"2.0","id":req_id,"result":{"id":sub_id,"refreshBefore":refresh,"cursor":None,"truncated":False}}


async def unsubscribe(req_id, params):
    name=params.get("name"); args=params.get("arguments") or {}; url=(params.get("delivery") or {}).get("url","")
    ident=json.dumps(["single-user",url,name,args],sort_keys=True,separators=(",",":"))
    sub_id="sub_"+hashlib.sha256(ident.encode()).hexdigest()[:24]
    db.delete_subscription(sub_id)
    return {"jsonrpc":"2.0","id":req_id,"result":{}}


async def verify_callback(sub_id: str, url: str, secret: str) -> bool:
    challenge=secrets.token_urlsafe(24)
    body=json.dumps({"type":"verification","challenge":challenge},separators=(",",":"),ensure_ascii=False).encode()
    headers=_signed_headers(secret,"msg_verification_"+secrets.token_hex(8),body,sub_id)
    try:
        async with httpx.AsyncClient(follow_redirects=False,timeout=5) as c:
            r=await c.post(url,content=body,headers=headers)
            if 200 <= r.status_code < 300:
                got=r.json().get("challenge")
                return isinstance(got,str) and hmac.compare_digest(got,challenge)
    except Exception: return False
    return False


async def deliver_event(event: RadarEvent) -> None:
    for sub in db.list_subscriptions(event.name):
        if not _matches(sub["arguments"],event.data): continue
        body=json.dumps({"eventId":event.event_id,"name":event.name,"timestamp":event.timestamp,"data":event.data,"cursor":None},separators=(",",":"),ensure_ascii=False).encode()
        headers=_signed_headers(sub["signing_secret"],event.event_id,body,sub["id"])
        try:
            _validate_callback_url(sub["callback_url"])
            async with httpx.AsyncClient(follow_redirects=False,timeout=10) as c:
                await c.post(sub["callback_url"],content=body,headers=headers)
        except Exception:
            pass


def _matches(arguments: dict, data: dict) -> bool:
    return all(not v or data.get(k)==v for k,v in arguments.items())


def _validate_secret(secret: str):
    if not secret.startswith("whsec_"): raise ValueError("secret must start with whsec_")
    try: raw=base64.b64decode(secret[6:],validate=True)
    except Exception: raise ValueError("invalid signing secret")
    if not 24 <= len(raw) <= 64: raise ValueError("signing secret must decode to 24-64 bytes")


def _validate_callback_url(url: str):
    p=urlparse(url)
    if p.scheme!="https" or not p.hostname: raise ValueError("callback must be public HTTPS")
    infos=socket.getaddrinfo(p.hostname,p.port or 443,type=socket.SOCK_STREAM)
    for info in infos:
        ip=ipaddress.ip_address(info[4][0])
        if not ip.is_global: raise ValueError("callback resolves to non-public IP")


def _signed_headers(secret: str, event_id: str, body: bytes, sub_id: str) -> dict[str,str]:
    ts=int(time.time()); key=base64.b64decode(secret[6:])
    signed_payload=event_id.encode()+b"."+str(ts).encode()+b"."+body
    digest=hmac.new(key,signed_payload,hashlib.sha256).digest()
    signature="v1,"+base64.b64encode(digest).decode("ascii")
    return {"Content-Type":"application/json","webhook-id":event_id,"webhook-timestamp":str(ts),"webhook-signature":signature,"X-MCP-Subscription-Id":sub_id}


def _err(req_id, code, message, data=None):
    err={"code":code,"message":message}
    if data is not None: err["data"]=data
    return {"jsonrpc":"2.0","id":req_id,"error":err}
