from __future__ import annotations
import asyncio, os, time
import httpx
from .config import load_targets
from .probe import probe_target
from .rules import derive_events
from . import db
from .mcp import deliver_event

class RadarEngine:
    def __init__(self):
        self.targets=[]
        self.next_due={}
        self.running=False
        self.last_reload=0.0
        self.max_concurrency=max(1,int(os.getenv("RADAR_MAX_CONCURRENCY","8")))
        self._sem=asyncio.Semaphore(self.max_concurrency)
        self.reload_targets()

    def reload_targets(self):
        current={t.id:t for t in load_targets()}
        self.targets=list(current.values())
        now=time.monotonic()
        self.next_due={tid:self.next_due.get(tid,0.0) for tid in current}
        self.last_reload=now

    async def _poll_one(self, client: httpx.AsyncClient, t):
        async with self._sem:
            prev=db.get_observation(t.id)
            obs=await probe_target(client,t)
            for e in derive_events(t,prev,obs):
                db.insert_event(e)
                await deliver_event(e)
            db.save_observation(obs)
            self.next_due[t.id]=time.monotonic()+max(15,t.interval_seconds)

    async def run(self):
        self.running=True
        headers={"User-Agent":os.getenv("RADAR_USER_AGENT","ReBASE-Radar/0.3")}
        limits=httpx.Limits(max_connections=max(10,self.max_concurrency*2),max_keepalive_connections=max(5,self.max_concurrency))
        async with httpx.AsyncClient(headers=headers,limits=limits) as client:
            while self.running:
                now=time.monotonic()
                if now-self.last_reload >= 15:
                    self.reload_targets()
                due=[t for t in self.targets if now >= self.next_due.get(t.id,0.0)]
                if due:
                    await asyncio.gather(*(self._poll_one(client,t) for t in due), return_exceptions=True)
                await asyncio.sleep(1)

    def stop(self): self.running=False
