"""Run with: PYTHONPATH=. python scripts/demo_transition.py"""
from radar.models import Target, Observation
from radar.rules import derive_events

t=Target(id="demo",name="Demo BOX",url="https://example.invalid",retailer="Demo",max_price_yen=5400)
prev={"in_stock":0,"reservation_open":0,"raffle_open":0,"price_yen":5400}
cur=Observation("demo","2026-10-07T00:00:00Z",200,True,False,False,5400,"x")
for e in derive_events(t,prev,cur): print(e.name,e.data)
