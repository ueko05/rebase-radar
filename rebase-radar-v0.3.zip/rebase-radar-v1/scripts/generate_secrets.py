import secrets
print("RADAR_MCP_TOKEN=" + secrets.token_urlsafe(48))
print("RADAR_ADMIN_TOKEN=" + secrets.token_urlsafe(48))
