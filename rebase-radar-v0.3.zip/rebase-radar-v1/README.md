# ReBASE Radar v0.3

ReBASEの仕入れシステム用に、**既知商品の高速監視（Radar）** と **dotによる新規機会の発見（Discovery）** を接続する土台です。

## いま出来ること

### Radar — 既知対象を高速監視
- YAMLまたはdotから追加された直商品/イベントURLを短周期監視
- `在庫なし → 在庫あり`
- 先着予約開始
- 抽選受付開始
- イベント参加受付開始
- 販売モード変更
- 重要告知ページ更新
- 価格上限内の商品を `purchase.candidate` 化
- Amazon.co.jpは販売元確認を必須化
- イオンの「抽選当選者のみ購入可能」を通常在庫と誤認しない

### Discovery — dot → Radar
v0.3ではdot側からRadarに新しい対象を**再起動なしで追加**できるようにしました。

- `radar_add_target`: 確認済み直URLをRadarへ追加
- `radar_ingest_opportunity`: 新商品・イベント・プロモ・抽選等をOpportunity DBへ保存し、必要なら同時にRadar登録
- `radar_list_targets`: 現在の監視対象を確認
- Runtime TargetはSQLiteへ保存され、Engineが15秒以内に再読込

これにより目標としている

`dotが新しい案件を発見 → Radarへ登録 → Radarが高速監視 → 条件成立 → dotへイベント → 購入/応募/通知 → Discoveryへ戻る`

のループを組めます。

## 30th CELEBRATION seed
初期seedとして以下を登録済みです。

- Amazon.co.jp 30thカードセット9種の直ページ
- イオンスタイルオンラインで確認できた直商品ページ
- ポケセンオンライン
- ヨドバシ
- あみあみ
- GEO
- ローソン
- Joshin
- ふるいち

Amazonは `Amazon.co.jp販売 + 価格上限内 + 通常購入可能` を満たさない限り `purchase.candidate` を出しません。

## Source Registry
`config/source_registry.yaml` は「今後dotが探す場所」のマスターです。

TCG販売店だけでなく、以下を含みます。
- Amazon / あみあみ / イオン / ヨドバシ / ビック / ヤマダ / コジマ
- GEO / ふるいち / TSUTAYA / BOOKOFF / MrMax
- 竜星のPAO / ドラゴンスター / イエローサブマリン / フルコンプ / カードボックス
- イトーヨーカドー / ドンキ
- ポケセン / プレバン / コナミスタイル
- ONE PIECE公式ショップ / 麦わらストア / JUMP SHOP / DRAGON BALL STORE TOKYO
- LivePocket / BANDAI TCG+ / ポケモンカード プレイヤーズクラブ
- 限定コラボ、無料配布、来場特典、プロモ、閉店/改装等

**Source Registryは高頻度クローラではありません。** dotが公開情報から有望な案件を発見し、監視価値のある直URLだけRadarへ昇格させます。

## Operator Profile
`config/operator_profile.yaml` に、応募資格・行動しやすい場所・通知優先度を分離しました。

現在は会話で確認済みの内容として、
- ビックカメラ: 購入履歴あり
- ヤマダデンキ: 購入履歴あり
- コジマ: 必要なら日用品購入で条件達成を検討
- 近隣優先: GEO / ふるいち
- 定期的に行ける拠点: 池袋
- オンライン完結/LivePocket系を優先

をseedにしています。条件が変わればこのファイルだけ更新します。

## Opportunity DB
新規案件は以下のような情報をSQLiteへ保存します。

- 種類: stock / restock / reservation / raffle / event_entry / promo / collab 等
- IP/作品
- 販売/応募元
- URL
- 開始・締切
- 場所
- 取得原価
- 想定価格（分かる場合のみ）
- 推定供給数（分かる場合のみ）
- Radar Target ID
- 詳細メモ

`priority_score` は**利益予測ではなく対応の緊急度**です。先着・現在購入可能・オンライン完結・応募資格あり等を上位にします。

## 起動

```bash
cp .env.example .env
# 本番では RADAR_MCP_TOKEN と RADAR_ADMIN_TOKEN を長いランダム値へ変更
docker compose up -d --build
curl http://localhost:8080/health
```

ローカルPython:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e '.[dev]'
uvicorn radar.api:app --reload --port 8080
```

## dot以外から動的ターゲットを追加する場合

```bash
curl -X POST http://localhost:8080/admin/targets \
  -H 'Content-Type: application/json' \
  -H 'X-Radar-Admin-Token: YOUR_TOKEN' \
  -d '{
    "id":"example-item",
    "name":"商品名",
    "url":"https://example.com/item",
    "retailer":"販売店",
    "priority":"S",
    "interval_seconds":30,
    "max_price_yen":1200,
    "required_any":["商品名"]
  }'
```

## イベント参加Radarの例

```yaml
id: example-tournament
name: "大会名"
url: "https://example.com/event"
retailer: "主催者"
category: event
priority: S
interval_seconds: 60
application_any:
  - "エントリー受付"
  - "参加申込"
metadata:
  mode: event_monitor
  purchase_eligible: false
```

受付開始を検知すると `application.opened` を出します。

## 自動購入について
v0.3でも購入ボタンの自動クリック自体はRadarに実装していません。

Radar = 高速な目  
dot = 判断・ブラウザ操作・人間への引き継ぎ

という分離を維持します。

CAPTCHA、待機列、本人確認、SMS等の回避機能は実装しません。各サイトの規約、購入制限、アクセス制限を守ります。

## 次の実装順
1. **24時間稼働する公開HTTPS環境へデプロイ**
2. 30thで通知のみの実戦ログを取得
3. 検知遅延・誤検知を測定
4. dotをMCP接続し `opportunity.discovered → radar_add_target` を実地テスト
5. HEROINES PRECIOUS BOX / Heroines Edition vol.2 / 今後のポケカ・ワンピ新商品を追加
6. LivePocket / BANDAI TCG+ / Players Clubのイベント監視を追加
7. 販売実績DBをつなぎ、仕入れ判断のフィードバックループを作る

## Railway 24時間稼働

本番公開用の `railway.toml` を同梱しています。`/health` だけを公開確認用に残し、`/targets`・`/events`・`/opportunities` は `X-Radar-Admin-Token` 必須にしました。

SQLiteを永続化するため、Railwayでは `/data` にVolumeを付けてください。詳しくは `DEPLOY_RAILWAY.md` を参照してください。
