import asyncio, json
from radar import db
from radar.mcp import tools_call


def test_dot_can_add_runtime_target(tmp_path, monkeypatch):
    monkeypatch.setattr(db,"DB_PATH",str(tmp_path/"radar.db"))
    db.init_db()
    params={"name":"radar_add_target","arguments":{"target":{
        "id":"dot-added","name":"Dot Added","url":"https://example.com/item","retailer":"Example",
        "required_any":["Dot Added"],"metadata":{"purchase_eligible":False}
    }}}
    out=asyncio.run(tools_call(1,params))
    assert out["result"]["structuredContent"]["ok"] is True
    assert db.list_runtime_targets()[0]["id"]=="dot-added"


def test_dot_can_ingest_opportunity_and_attach_target(tmp_path, monkeypatch):
    monkeypatch.setattr(db,"DB_PATH",str(tmp_path/"radar.db"))
    db.init_db()
    params={"name":"radar_ingest_opportunity","arguments":{
      "opportunity":{"kind":"event_entry","title":"Example tournament","online":True,"user_eligible":True},
      "radar_target":{"id":"event-1","name":"Example tournament","url":"https://example.com/event","retailer":"Organizer","category":"event","application_any":["エントリー受付"]}
    }}
    out=asyncio.run(tools_call(2,params))
    data=out["result"]["structuredContent"]
    assert data["ok"] is True
    assert data["radar_target_id"]=="event-1"
    assert db.list_opportunities()[0]["title"]=="Example tournament"
