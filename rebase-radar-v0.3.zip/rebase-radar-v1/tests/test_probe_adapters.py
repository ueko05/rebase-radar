from bs4 import BeautifulSoup
from radar.models import Target
from radar.probe import _parse_amazon_jp, _parse_aeon_style


def test_amazon_invite_not_stock():
    t=Target(id="a",name="x",url="x",retailer="Amazon.co.jp",
             metadata={"seller_required":"Amazon.co.jp"})
    text="ポケモンカード 招待をリクエスト 販売元 Amazon.co.jp ￥1,200"
    soup=BeautifulSoup('<span class="a-price"><span class="a-offscreen">￥1,200</span></span>', 'html.parser')
    d=_parse_amazon_jp(text,t,None,soup)
    assert d["in_stock"] is False
    assert d["offer_mode"] == "invite_request"
    assert d["seller_verified"] is True


def test_amazon_direct_purchase_and_seller():
    t=Target(id="a",name="x",url="x",retailer="Amazon.co.jp",
             metadata={"seller_required":"Amazon.co.jp"})
    text="ポケモンカード カートに入れる 今すぐ買う 販売元 Amazon.co.jp"
    soup=BeautifulSoup('<div id="corePrice_feature_div"><span class="a-price"><span class="a-offscreen">￥1,200</span></span></div>', 'html.parser')
    d=_parse_amazon_jp(text,t,None,soup)
    assert d["in_stock"] is True
    assert d["offer_mode"] == "direct_purchase"
    assert d["seller_verified"] is True
    assert d["price_yen"] == 1200


def test_aeon_lottery_winner_only_not_stock():
    t=Target(id="i",name="x",url="x",retailer="イオンスタイルオンライン")
    d=_parse_aeon_style("抽選販売商品です。当選者の方のみ購入可能な商品です。 税込 1,199円",t,None)
    assert d["in_stock"] is False
    assert d["raffle_open"] is True
    assert d["offer_mode"] == "lottery_winner_only"
