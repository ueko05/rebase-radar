from radar.opportunity import priority_score


def test_online_current_eligible_first_come_scores_high():
    s=priority_score({"kind":"first_come","currently_available":True,"online":True,"user_eligible":True,"official_or_authorized":True})
    assert s >= 80


def test_unknown_eligibility_is_penalized():
    a=priority_score({"kind":"raffle","requires_unknown_eligibility":True})
    b=priority_score({"kind":"raffle","user_eligible":True})
    assert b > a
