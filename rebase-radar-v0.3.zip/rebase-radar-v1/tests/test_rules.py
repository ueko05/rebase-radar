from radar.models import Target, Observation
from radar.rules import derive_events

def test_stock_transition_and_purchase_candidate():
    t=Target(id="x",name="x",url="https://x",retailer="x",max_price_yen=1200)
    prev={"in_stock":0,"reservation_open":0,"raffle_open":0,"price_yen":1200}
    cur=Observation("x","now",200,True,False,False,1200,"f")
    names=[e.name for e in derive_events(t,prev,cur)]
    assert "inventory.available" in names
    assert "purchase.candidate" in names

def test_over_price_not_purchase_candidate():
    t=Target(id="x",name="x",url="https://x",retailer="x",max_price_yen=1200)
    prev={"in_stock":0,"reservation_open":0,"raffle_open":0,"price_yen":1200}
    cur=Observation("x","now",200,True,False,False,5000,"f")
    names=[e.name for e in derive_events(t,prev,cur)]
    assert "inventory.available" in names
    assert "purchase.candidate" not in names

def test_required_seller_blocks_purchase_candidate_when_unverified():
    t=Target(id="x",name="x",url="https://x",retailer="Amazon.co.jp",max_price_yen=1200,
             metadata={"seller_required":"Amazon.co.jp"})
    prev={"in_stock":0,"reservation_open":0,"raffle_open":0,"price_yen":1200,"seller_verified":0}
    cur=Observation("x","now",200,True,False,False,1200,"f",seller_verified=False,offer_mode="direct_purchase")
    names=[e.name for e in derive_events(t,prev,cur)]
    assert "inventory.available" in names
    assert "purchase.candidate" not in names


def test_required_seller_allows_purchase_candidate_when_verified():
    t=Target(id="x",name="x",url="https://x",retailer="Amazon.co.jp",max_price_yen=1200,
             metadata={"seller_required":"Amazon.co.jp"})
    prev={"in_stock":0,"reservation_open":0,"raffle_open":0,"price_yen":1200,"seller_verified":0}
    cur=Observation("x","now",200,True,False,False,1200,"f",seller_verified=True,offer_mode="direct_purchase")
    names=[e.name for e in derive_events(t,prev,cur)]
    assert "purchase.candidate" in names


def test_invite_mode_never_auto_purchase():
    t=Target(id="x",name="x",url="https://x",retailer="Amazon.co.jp",max_price_yen=1200,
             metadata={"seller_required":"Amazon.co.jp"})
    prev={"in_stock":0,"reservation_open":0,"raffle_open":0,"price_yen":1200,"seller_verified":1}
    cur=Observation("x","now",200,False,True,True,1200,"f",seller_verified=True,offer_mode="invite_request")
    names=[e.name for e in derive_events(t,prev,cur)]
    assert "purchase.candidate" not in names
