from pathlib import Path
from radar import db
from radar.config import load_targets


def test_runtime_target_is_merged(tmp_path, monkeypatch):
    dbfile=tmp_path/"radar.db"
    monkeypatch.setattr(db,"DB_PATH",str(dbfile))
    db.init_db()
    db.upsert_runtime_target({
        "id":"dynamic-1","name":"Dynamic","url":"https://example.com/p","retailer":"Example",
        "priority":"S","interval_seconds":30,"max_price_yen":1000,"required_any":["Dynamic"]
    })
    cfg=tmp_path/"targets.yaml"
    cfg.write_text("defaults:\n  in_stock_any: ['カートに入れる']\ntargets: []\n",encoding="utf-8")
    targets=load_targets(str(cfg))
    assert len(targets)==1
    assert targets[0].id=="dynamic-1"
    assert targets[0].in_stock_any==["カートに入れる"]
